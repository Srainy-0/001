package com.exmaple.shayuxiwubloodcore;

import net.minecraft.Util;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.jetbrains.annotations.NotNull;

@Mod("com/exmaple/shayuxiwubloodcore")
@Mod.EventBusSubscriber
public class main {
   @SubscribeEvent
    public static void  playerinputworld(PlayerEvent.@NotNull PlayerLoggedInEvent event){
       Player player = event.getPlayer();
       Level level = player.level;

       player.sendMessage(new TextComponent("hellow,"+player.getScoreboardName().toString()+" form "+(level.isClientSide()?"client":"server")+"."),Util.NIL_UUID);
    }


}
